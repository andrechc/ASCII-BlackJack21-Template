
public enum tipo {
	JUGADOR, CRUIPER;
}
